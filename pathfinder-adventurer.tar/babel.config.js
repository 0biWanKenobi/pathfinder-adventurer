/* eslint-env commonjs */
module.exports = {
  presets: ["@vue/app"]
};
//, "@vue/cli-plugin-babel/preset"
